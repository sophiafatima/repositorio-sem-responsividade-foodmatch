<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use GuzzleHttp\Client;

class ReceitaController extends Controller
{
    public function buscarReceita()
{
    $receita = "Receita de bolo simples";

    // Salvar em sessão (simulado)
    session()->push('historico_receitas', $receita);

    return view('storage.app.public.receitas.resultado', compact('receita'));
}


    // Função para salvar as receitas no histórico
    private function salvarHistorico($receita)
    {
        // Salvar em uma sessão ou banco de dados (ajustar conforme necessidade)
        session()->push('historico_receitas', $receita);
    }

    public function salvarReceita(Request $request)
    {
        $receita = $request->input('receita');
        $arquivo = storage_path('app/public/receitas/' . time() . '.txt');
        file_put_contents($arquivo, $receita);
        return response()->json(['message' => 'Receita salva com sucesso!', 'arquivo' => $arquivo]);
    }
}
